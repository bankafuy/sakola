<?php include "page/body.php"?>
<center>
<body>
	<p>----------- Content -----------<br>--- AIJ XII ---<br><a href="#" target="_blank" rel="nofollow">Load Balance</a><br><a href="page/mapel/AIJ/#" target="_blank" rel="nofollow">Web Proxy - Squid</a><br>--------- End-Content ---------</p>
</center>
</body>