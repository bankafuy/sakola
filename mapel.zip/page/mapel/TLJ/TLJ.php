<?php include "page/body.php"?>
<center>
<body>
	<p>----------- Content -----------<br>--- TLJ XII ---<br><a href="#" target="_blank" rel="nofollow">IP Phone</a><br><a href="page/mapel/AIJ/#" target="_blank" rel="nofollow">Linphone</a><br>--------- End-Content ---------</p>
</center>
</body>