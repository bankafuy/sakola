<?php include "page/body.php"?>
<center>
<body>
	<p>----------- Content -----------<br>--- ASJ XII ---<br><a href="#" target="_blank" rel="nofollow">Munin</a><br><a href="page/mapel/ASJ/nagios.txt" target="_blank" rel="nofollow">Nagios</a><br><a href="#" target="_blank" rel="nofollow">Web Proxy - Squid</a><br>--------- End-Content ---------</p>
</center>
</body>