<?php include "body.php"?>
<center>
<body>
	<p>----------- About-Me -----------<h3>Muhammad Ichsan Haekal</h3>You can find me:<br><a href="https://instagram.com/leemrtnzz">Instagram</a> - <a href="https://fb.me/leemrtnzz">Facebook</a><br>-------------- End --------------</p>
</center>
</body>