<?php include "body.php"?>
<center>
<body>
	<p>----------- Welcome -----------<br>Website ini dibuat hanya untuk pembelajaran,<br>masih tahap
		pengembangan.<br>--- Keep-Enjoy ---</p>
</center>
</body>