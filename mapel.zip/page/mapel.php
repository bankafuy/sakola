<?php include "body.php"?>
<center>
<body>
	<p>----------- Content -----------<br>--- XII ---<br><a href="?mapel=ASJ">Administrasi Sistem Jaringan</a><br><a href="?mapel=AIJ">Administrasi Infrastruktur Jaringan</a><br><a href="?mapel=TLJ">Teknologi Layanan dan Jaringan</a><br>--- XI ---<br>Comingsoon<br>--- X ---<br>Comingsoon<br>--------- End-Content ---------</p>
</body>
</center>