<div class="footer">
	<center>
		<p>Copyright - 2020</p>
	</center>
</div>
</html>