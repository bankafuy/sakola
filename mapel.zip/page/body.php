<!DOCTYPE html>
<html>
<head>
	<title>?x000</title>
	<link rel="stylesheet" type="text/css" href="https://fonts.google.com/css?family=Roboto+Mono&display=swap">
</head>
<style type="text/css">
	.nav {
		margin: 100px 3px 3px 600px;
	}
	body, p, h1, h2, h3, h4, h5, a {
		font-family: 'Roboto Mono', monospace;
		font-color: black;
		text-decoration: none;
	}
</style>